let choices = ["rock","paper","scissors"];

let randomIndex = Math.floor(Math.random()*3);

let computer = choices[randomIndex];

let user = prompt("choose- rock, paper or scissors");

alert("Computer chose: " + computer);

if(user == computer){
    alert("Draw 😄");
}

else if(
(user == "rock" && computer == "scissors") ||
(user == "paper" && computer == "rock") ||
(user == "scissors" && computer == "paper")
){
    alert("You Win 🎉");
}

else{
    alert("Computer Wins🤣🤪 ");
}
